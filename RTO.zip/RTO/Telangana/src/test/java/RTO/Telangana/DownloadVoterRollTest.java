package RTO.Telangana;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import net.sourceforge.tess4j.ITesseract;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

import java.util.HashMap;
import java.util.Set;
import utils.BaseFile;

public class DownloadVoterRollTest extends BaseFile {

    @Test
    public void downloadVoterRoll() throws IOException, TesseractException, InterruptedException
    {
    	String downloadFilepath = System.getProperty("user.dir") + File.separator + "downloads";
    	 
        ChromeOptions options = new ChromeOptions();
        
        HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
        chromeOptionsMap.put("plugins.plugins_disabled", new String[] { "Chrome PDF Viewer" });
        chromeOptionsMap.put("plugins.always_open_pdf_externally", true);
        chromeOptionsMap.put("download.default_directory", downloadFilepath);
        options.setExperimentalOption("prefs", chromeOptionsMap);
        options.addArguments("--headless");      
        
        driver.get("https://ceotserms2.telangana.gov.in/ts_erolls/rolls.aspx");

		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(120));

        // Select District
        WebElement districtDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ContentPlaceHolder1_ddlDist")));
        districtDropdown.click();
       
        WebElement district = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//option[@value='17']"))); // Hyderabad
        district.click();

        // Select Assembly Constituency
        WebElement constituencyDropdown = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("ctl00_ContentPlaceHolder1_ddlAC")));
        constituencyDropdown.click();
        
        WebElement constituency = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//option[@value='60']"))); //Khairatabad
        constituency.click();

        // Select Polling Station
        WebElement pollingStation = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Get Polling Stations']")));
        pollingStation.click();     

        // Click the "Get Roll" button       
        Thread.sleep(2000);
        String parentwindowhandle = driver.getWindowHandle(); 
        System.out.println("The parent handle is: "+ parentwindowhandle);  
        WebElement getRollButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[contains(text(),'View')])[2]"))); //English
        getRollButton.click();
      
        Set<String> handles = driver.getWindowHandles(); 
        for(String handle:handles) { System.out.println(handle); 
        if(!handle.equals(parentwindowhandle)) 
        { driver.switchTo().window(handle); 
        
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@id='txtVerificationCode']"))); //English      
        Thread.sleep(2000);
        
        // Store the Captcha in folder
        File src=driver.findElement(By.id("Image2")).getScreenshotAs(OutputType.FILE); 
        Thread.sleep(2000);
        String path=System.getProperty("user.dir")+"/screenshots/captcha.png"; 
        FileHandler.copy(src, new File(path)); 
        Thread.sleep(2000);
        
        // Read the Captcha and print it
        ITesseract image = new Tesseract();
        Thread.sleep(2000);
        image.setTessVariable("user_defined_dpi", "500");
        Thread.sleep(2000);
        String imageText=image.doOCR(new File(path));
        Thread.sleep(2000);
        System.out.println(imageText);
        String finalText=imageText.replaceAll("[^a-zA-Z0-9]",""); 
        System.out.println("Final Captcha is "+finalText);
        Thread.sleep(2000);
        driver.findElement(By.id("txtVerificationCode")).sendKeys(finalText);

        // Wait for the download link to be visible
        WebElement Submitbtn = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("btnSubmit")));
        Submitbtn.click();   
        Thread.sleep(5000);
        
        // to close the Voterlist PDF captcha window
        driver.close();       
        
        // to switch to parent window.
        driver.switchTo().window(parentwindowhandle);

        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//a[contains(text(),'View')])[2]"))); //Previos Page 
        Thread.sleep(2000);
                      
   }   
  }
 }
}

    


