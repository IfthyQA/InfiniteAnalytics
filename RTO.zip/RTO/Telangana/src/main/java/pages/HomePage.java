package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HomePage {
    WebDriver driver;

    @FindBy(id = "ctl00_ContentPlaceHolder1_ddlDist") 
    WebElement districtDropdown;
    
    @FindBy(id = "ctl00_ContentPlaceHolder1_ddlAC") 
    WebElement assemblyConstituencyDropdown;
    
    @FindBy(id = "ctl00_ContentPlaceHolder1_btnlogin") 
    WebElement pollingStationDropdown;
    
    @FindBy(id = "btnDownload") 
    WebElement downloadButton;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void selectDistrict(String district) {
        new Select(districtDropdown).selectByVisibleText(district);
    }

    public void selectAssemblyConstituency(String constituency) {
        new Select(assemblyConstituencyDropdown).selectByVisibleText(constituency);
    }

    public void selectPollingStation(String pollingStation) {
        new Select(pollingStationDropdown).selectByVisibleText(pollingStation);
    }

    public void clickDownloadButton() {
        downloadButton.click();
    }
}